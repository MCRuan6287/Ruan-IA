import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, X, FileImage, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FileUploadProps {
  onFileSelect: (file: File, base64: string) => void;
  accept?: string;
  maxSize?: number; // in MB
  mode: "chat" | "image";
}

export function FileUpload({ onFileSelect, accept = "*/*", maxSize = 10, mode }: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const getAcceptedTypes = () => {
    if (mode === "image") {
      return "image/*";
    }
    return "image/*,.pdf,.txt,.doc,.docx,.json";
  };

  const handleFileSelect = async (file: File) => {
    if (file.size > maxSize * 1024 * 1024) {
      toast({
        title: "Arquivo muito grande",
        description: `O arquivo deve ter no máximo ${maxSize}MB.`,
        variant: "destructive",
      });
      return;
    }

    // Check file type based on mode
    if (mode === "image" && !file.type.startsWith("image/")) {
      toast({
        title: "Tipo de arquivo não suportado",
        description: "No modo imagem, apenas arquivos de imagem são aceitos.",
        variant: "destructive",
      });
      return;
    }

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        onFileSelect(file, base64);
        setSelectedFile(file);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast({
        title: "Erro ao processar arquivo",
        description: "Não foi possível processar o arquivo selecionado.",
        variant: "destructive",
      });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith("image/")) {
      return <FileImage className="h-4 w-4" />;
    }
    return <FileText className="h-4 w-4" />;
  };

  return (
    <div className="space-y-2">
      {!selectedFile && (
        <Card 
          className={`border-2 border-dashed transition-colors cursor-pointer ${
            isDragOver 
              ? "border-blue-400 bg-blue-50 dark:bg-blue-950" 
              : "border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500"
          }`}
          onDrop={handleDrop}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragOver(true);
          }}
          onDragLeave={() => setIsDragOver(false)}
          onClick={() => fileInputRef.current?.click()}
        >
          <CardContent className="flex flex-col items-center justify-center py-6 px-4">
            <Upload className="h-8 w-8 text-gray-400 mb-2" />
            <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
              {mode === "image" 
                ? "Arraste uma imagem aqui ou clique para selecionar"
                : "Arraste um arquivo aqui ou clique para selecionar"
              }
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
              {mode === "image" 
                ? "Aceita: JPG, PNG, GIF, WebP"
                : "Aceita: Imagens, PDF, TXT, DOC, JSON"
              } (máx. {maxSize}MB)
            </p>
          </CardContent>
        </Card>
      )}

      {selectedFile && (
        <Card className="border-green-200 bg-green-50 dark:bg-green-950 dark:border-green-800">
          <CardContent className="flex items-center justify-between py-3 px-4">
            <div className="flex items-center gap-3">
              {getFileIcon(selectedFile)}
              <div>
                <p className="text-sm font-medium text-green-800 dark:text-green-200">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-green-600 dark:text-green-400">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)}MB
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFile}
              className="text-green-700 hover:text-green-800 dark:text-green-300 dark:hover:text-green-200"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept={getAcceptedTypes()}
        onChange={handleFileInputChange}
        className="hidden"
      />
    </div>
  );
}