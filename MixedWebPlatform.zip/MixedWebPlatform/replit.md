# replit.md

## Overview

This is a full-stack AI chat application called "Ruan IA" built with React, Express, and PostgreSQL. The application provides an intelligent chat interface powered by Google's Gemini AI, featuring both text conversations and image generation capabilities. Users can register accounts, authenticate, and engage in conversations with an AI assistant that supports web search grounding and file uploads.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server:

### Frontend Architecture
- **Framework**: React 19 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui components for consistent design
- **State Management**: React hooks for local state, no external state management library
- **Progressive Web App**: Service worker implementation with manifest for installable experience

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with proper error handling
- **Session Management**: Express sessions with PostgreSQL storage

### Database Architecture
- **Primary Database**: PostgreSQL via Drizzle ORM
- **Schema Management**: Drizzle Kit for migrations and schema evolution
- **Connection**: Neon Database serverless PostgreSQL

## Key Components

### Authentication System
- **Local Authentication**: Custom email/password system with bcrypt hashing
- **Session Storage**: Server-side sessions stored in PostgreSQL
- **Client Storage**: Fallback localStorage implementation for development/demo

### AI Integration
- **Provider**: Google Gemini 2.5 Flash model via @google/genai
- **Features**: 
  - Text chat with system instructions
  - Image upload and analysis
  - Web search grounding for up-to-date information
  - Streaming responses for real-time interaction
  - Image generation capabilities with Gemini 2.0 Flash Image Generation
  - Enhanced file upload support (images, PDFs, documents)
  - Dual mode interface: Chat mode (text + optional image uploads) and Image mode (pure image generation)

### UI Components
- **Design System**: shadcn/ui components built on Radix UI primitives
- **Responsive Design**: Mobile-first approach with Tailwind responsive utilities
- **Accessibility**: WCAG compliant components with proper ARIA labels
- **Theme**: Dark theme optimized for chat interfaces

### Storage Strategy
- **Database**: PostgreSQL with DatabaseStorage class using Drizzle ORM
- **Tables**: 
  - `users` (id, name, email, password, picture, created_at)
  - `messages` (id, user_id, role, content, image_url, metadata, created_at)
  - `reviews` (id, user_id, rating, comment, created_at) - NEW
- **File Handling**: Base64 encoding for image uploads with enhanced FileUpload component
- **Connection**: Neon serverless PostgreSQL with connection pooling

## Data Flow

### Authentication Flow
1. User registers/logs in via form submission
2. Server validates credentials and creates session
3. Session token stored in HTTP-only cookies
4. Client receives user data and updates UI state
5. Subsequent requests include session cookie for authentication

### Chat Flow
1. User submits message through ChatInput component
2. Message sent to Gemini API with streaming enabled
3. Server streams response chunks back to client
4. Client renders messages in real-time with typing indicators
5. Messages and metadata stored in database for persistence

### Image Handling
1. User uploads image file through file input
2. File converted to base64 on client side
3. Base64 data sent with message to server
4. Server forwards to Gemini API for analysis
5. Generated images displayed with modal view and download capability

## External Dependencies

### AI Services
- **Google Gemini API**: Core AI functionality requiring GEMINI_API_KEY environment variable
- **Web Search**: Integrated grounding search through Gemini's tools

### Development Tools
- **Vite**: Development server with HMR and build optimization
- **Replit Integration**: Special plugins for Replit development environment
- **Service Worker**: PWA capabilities with caching strategies

### UI Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library for consistent iconography

## Deployment Strategy

### Development
- **Local Development**: `npm run dev` starts both client and server
- **Hot Reload**: Vite HMR for frontend, tsx for backend file watching
- **Environment**: NODE_ENV=development enables development features

### Production Build
- **Client Build**: Vite builds optimized React bundle to `dist/public`
- **Server Build**: esbuild bundles Express server to `dist/index.js`
- **Static Serving**: Express serves built client files in production

### Environment Configuration
- **Required Variables**: 
  - `DATABASE_URL`: PostgreSQL connection string
  - `GEMINI_API_KEY`: Google Gemini API access key
- **Optional Variables**:
  - `NODE_ENV`: Environment mode (development/production)
  - `PORT`: Server port (defaults to process.env.PORT)

### Database Setup
- **Schema Management**: Run `npm run db:push` to sync schema with database
- **Migrations**: Automatic schema evolution via Drizzle migrations in `migrations/` folder
- **Connection**: Uses connection pooling with Neon serverless PostgreSQL

The application is designed to be easily deployable on platforms like Vercel, Railway, or Heroku with minimal configuration changes.