import React, { useState } from 'react';
import { BotIcon } from './icons';
import { User } from '../types';
import authService from '../services/authService';

interface LoginProps {
    onAuthSuccess: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onAuthSuccess }) => {
    const [isSignUp, setIsSignUp] = useState(false);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);

        try {
            let user;
            if (isSignUp) {
                if (!name.trim()) {
                    setError("O nome é obrigatório.");
                    return;
                }
                user = authService.signUp(name, email, password);
            } else {
                user = authService.login(email, password);
            }
            onAuthSuccess(user);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Ocorreu um erro desconhecido.");
        }
    };

    const toggleForm = () => {
        setIsSignUp(!isSignUp);
        setError(null);
        setName('');
        setEmail('');
        setPassword('');
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-slate-900 text-slate-300 p-4">
            <main className="w-full max-w-md mx-auto">
                <div className="text-center mb-8">
                    <div className="inline-block p-4 bg-slate-800 rounded-full mb-4">
                        <BotIcon />
                    </div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">
                        {isSignUp ? 'Crie uma Conta' : 'Bem-vindo ao Ruan IA'}
                    </h1>
                    <p className="text-slate-400 mt-2">
                        {isSignUp ? 'Comece com seu assistente de IA pessoal.' : 'Faça login para continuar.'}
                    </p>
                </div>

                <div className="bg-slate-800/50 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        {isSignUp && (
                            <div>
                                <label className="text-sm font-bold text-slate-400 block mb-2" htmlFor="name">Nome</label>
                                <input
                                    id="name"
                                    type="text"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className="w-full bg-slate-900 rounded-md py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                                    placeholder="Seu Nome"
                                    required
                                />
                            </div>
                        )}
                        <div>
                            <label className="text-sm font-bold text-slate-400 block mb-2" htmlFor="email">E-mail</label>
                            <input
                                id="email"
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full bg-slate-900 rounded-md py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                                placeholder="voce@exemplo.com"
                                required
                            />
                        </div>
                        <div>
                            <label className="text-sm font-bold text-slate-400 block mb-2" htmlFor="password">Senha</label>
                            <input
                                id="password"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full bg-slate-900 rounded-md py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                                placeholder="••••••••"
                                minLength={6}
                                required
                            />
                        </div>
                        
                        {error && (
                            <p className="text-red-400 text-sm text-center bg-red-900/50 p-3 rounded-md">{error}</p>
                        )}

                        <button
                            type="submit"
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition-colors duration-300"
                        >
                            {isSignUp ? 'Criar Conta' : 'Entrar'}
                        </button>
                    </form>

                    <p className="text-center text-slate-400 text-sm mt-6">
                        {isSignUp ? 'Já tem uma conta?' : "Não tem uma conta?"}
                        <button onClick={toggleForm} className="font-bold text-blue-400 hover:text-blue-300 ml-2 focus:outline-none">
                            {isSignUp ? 'Entrar' : 'Cadastre-se'}
                        </button>
                    </p>
                </div>
            </main>
            <footer className="mt-8 text-center text-xs text-slate-500">
                <p>&copy; 2024 Ruan IA. Todos os direitos reservados.</p>
            </footer>
        </div>
    );
};

export default Login;