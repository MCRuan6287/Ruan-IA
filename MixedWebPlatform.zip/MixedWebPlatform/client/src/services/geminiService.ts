import { GoogleGenAI, Modality } from "@google/genai";
import { UploadedFile } from '../types';

// Initialize with empty key, will be loaded from server
let apiKey = '';
let ai: GoogleGenAI | null = null;

// Fetch API key from server
async function initializeGemini() {
  if (!apiKey) {
    try {
      const response = await fetch('/api/config');
      const config = await response.json();
      apiKey = config.geminiApiKey;
      if (apiKey) {
        ai = new GoogleGenAI({ apiKey });
      } else {
        console.error("GEMINI_API_KEY not found in server config");
      }
    } catch (error) {
      console.error("Failed to fetch API key from server:", error);
    }
  }
  return ai;
}

interface ImageGenerationParams {
  prompt: string;
  negativePrompt?: string;
  aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4";
}

class GeminiChatService {
  private chat: any = null;

  private async initializeChat() {
    if (!this.chat) {
      const aiInstance = await initializeGemini();
      if (!aiInstance) {
        throw new Error("Failed to initialize Gemini AI");
      }
      this.chat = aiInstance.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: 'You are a helpful and creative AI assistant named Ruan IA. Provide clear, concise, and friendly responses. When asked for information that might be recent or require web access, you will use your search tool to provide up-to-date answers and cite your sources.',
          tools: [{ googleSearch: {} }],
        },
      });
    }
    return this.chat;
  }

  public async *sendMessageStream(message: string, file?: UploadedFile): AsyncGenerator<{type: 'text'; payload: string} | {type: 'metadata'; payload: any}> {
    const aiInstance = await initializeGemini();
    if (!aiInstance) {
      throw new Error("GEMINI_API_KEY not configured. Please check your API key settings.");
    }
    
    try {
      const chat = await this.initializeChat();
      
      let streamRequest: string | any[];
      if (file) {
        streamRequest = [
          { text: message },
          {
            inlineData: {
              mimeType: file.type,
              data: file.data
            }
          }
        ];
      } else {
        streamRequest = message;
      }

      const result = await chat.sendMessageStream({ message: streamRequest });
      let finalResponse: any = null;

      for await (const chunk of result) {
        finalResponse = chunk;
        if (chunk.text) {
          yield { type: 'text', payload: chunk.text };
        }
      }
      
      const metadata = finalResponse?.candidates?.[0]?.groundingMetadata;
      if (metadata?.groundingChunks?.length) {
        yield { type: 'metadata', payload: metadata };
      }

    } catch (error) {
      console.error("Error sending message to Gemini:", error);
      throw new Error("Falha ao obter resposta da IA. Verifique sua chave de API e conexão de rede.");
    }
  }
  
  public async generateImage(params: ImageGenerationParams): Promise<string> {
    const aiInstance = await initializeGemini();
    if (!aiInstance) {
      throw new Error("GEMINI_API_KEY not configured. Please check your API key settings.");
    }
    try {
      const response = await aiInstance.models.generateContent({
        model: "gemini-2.0-flash-preview-image-generation",
        contents: [{ role: "user", parts: [{ text: params.prompt }] }],
        config: {
          responseModalities: [Modality.TEXT, Modality.IMAGE],
        },
      });

      const candidates = response.candidates;
      if (!candidates || candidates.length === 0) {
        throw new Error("A IA não conseguiu gerar uma imagem. Tente um prompt diferente.");
      }

      const content = candidates[0].content;
      if (!content || !content.parts) {
        throw new Error("A IA não conseguiu gerar uma imagem. Tente um prompt diferente.");
      }

      for (const part of content.parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:image/jpeg;base64,${part.inlineData.data}`;
        }
      }
      
      throw new Error("A IA não conseguiu gerar uma imagem. Tente um prompt diferente.");
    } catch (error) {
      console.error("Error generating image with Gemini:", error);
      throw new Error("Falha ao gerar a imagem. Verifique seu prompt e tente novamente.");
    }
  }
}

const geminiService = new GeminiChatService();
export default geminiService;
