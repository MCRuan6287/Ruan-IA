import React from 'react';
import { BotIcon, LogoutIcon } from './icons';
import { User } from '../types';

interface HeaderProps {
    user: User | null;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  return (
    <header className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700 p-4 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-4">
            <BotIcon />
            <h1 className="text-xl font-bold text-slate-100">Ruan IA</h1>
            <span className="text-xs bg-slate-700 text-blue-400 px-2 py-1 rounded-md hidden sm:inline">Model: gemini-2.5-flash</span>
        </div>
        {user && (
            <div className="flex items-center gap-2 sm:gap-4">
                <span className="hidden sm:inline text-sm text-slate-300">Bem-vindo, {user.name.split(' ')[0]}</span>
                <img src={user.picture} alt={user.name} className="h-8 w-8 rounded-full" referrerPolicy="no-referrer" />
                <button onClick={onLogout} className="text-slate-400 hover:text-white transition-colors" aria-label="Sair">
                    <LogoutIcon />
                </button>
            </div>
        )}
      </div>
    </header>
  );
};

export default Header;