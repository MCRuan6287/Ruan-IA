// IMPORTANT: Replace with your actual Google Client ID.
// You can get one from the Google Cloud Console: https://console.cloud.google.com/apis/credentials
export const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';
