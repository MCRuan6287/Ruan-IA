
export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
  ERROR = 'error',
  IMAGE = 'image',
}

export interface UploadedFile {
  name: string;
  type: string; // MIME type
  data: string; // base64 encoded data
}

export interface Message {
  role: MessageRole;
  text: string;
  imageUrl?: string;
  negativePrompt?: string;
  aspectRatio?: string;
  groundingMetadata?: any;
  file?: UploadedFile;
}

export interface User {
    name: string;
    email: string;
    picture: string;
}
