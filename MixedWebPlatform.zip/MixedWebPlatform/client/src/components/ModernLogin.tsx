import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Brain, AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { User } from '../types';
import authService from '../services/authService';

interface LoginProps {
  onAuthSuccess: (user: User) => void;
}

const ModernLogin: React.FC<LoginProps> = ({ onAuthSuccess }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setIsLoading(true);

    try {
      let user;
      if (isSignUp) {
        if (!name.trim()) {
          setError("O nome é obrigatório.");
          setIsLoading(false);
          return;
        }
        user = authService.signUp(name, email, password);
        setSuccess("Conta criada com sucesso! Você já está logado.");
      } else {
        user = authService.login(email, password);
        setSuccess("Login realizado com sucesso!");
      }
      
      setTimeout(() => {
        onAuthSuccess(user);
      }, 1000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ocorreu um erro desconhecido.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleForm = () => {
    setIsSignUp(!isSignUp);
    setError(null);
    setSuccess(null);
    setName('');
    setEmail('');
    setPassword('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="w-full max-w-lg space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full">
            <Brain className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
              Ruan IA
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Seu assistente de IA pessoal
            </p>
            <Badge variant="secondary" className="mt-2">
              v2.1.0 • Gemini 2.5 Flash
            </Badge>
          </div>
        </div>

        {/* Info Cards */}
        {!isSignUp && (
          <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              Faça login para acessar suas conversas salvas e histórico personalizado.
            </AlertDescription>
          </Alert>
        )}

        {isSignUp && (
          <Alert className="border-green-200 bg-green-50 dark:bg-green-950 dark:border-green-800">
            <CheckCircle2 className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800 dark:text-green-200">
              Crie sua conta para salvar conversas e personalizar sua experiência.
            </AlertDescription>
          </Alert>
        )}

        {/* Login/Signup Card */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-center">
              {isSignUp ? 'Criar Nova Conta' : 'Entrar na Conta'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Seu nome"
                    required
                    disabled={isLoading}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Sua senha"
                  required
                  disabled={isLoading}
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="border-green-200 bg-green-50 dark:bg-green-950">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 dark:text-green-200">
                    {success}
                  </AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit" 
                className="w-full" 
                disabled={isLoading}
              >
                {isLoading 
                  ? (isSignUp ? "Criando conta..." : "Entrando...") 
                  : (isSignUp ? "Criar Conta" : "Entrar")
                }
              </Button>
            </form>

            <div className="text-center">
              <Button 
                variant="link" 
                onClick={toggleForm}
                disabled={isLoading}
                className="text-sm"
              >
                {isSignUp 
                  ? 'Já tem uma conta? Entre aqui' 
                  : 'Não tem conta? Crie uma agora'
                }
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Features Info */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border-purple-200 dark:border-purple-800">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-purple-800 dark:text-purple-200 mb-3">
              Recursos Disponíveis:
            </h3>
            <ul className="space-y-2 text-sm text-purple-700 dark:text-purple-300">
              <li>• Chat inteligente com IA</li>
              <li>• Geração de imagens</li>
              <li>• Upload e análise de arquivos</li>
              <li>• Instalável como aplicativo (PWA)</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ModernLogin;