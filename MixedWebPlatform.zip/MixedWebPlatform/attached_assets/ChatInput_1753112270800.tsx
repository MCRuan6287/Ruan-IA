
import React, { useState, useRef } from 'react';
import { SendIcon, LoadingSpinner, PaperclipIcon, CloseIcon } from './icons';
import { UploadedFile } from '../types';

interface ChatInputProps {
  onSendMessage: (message: string, file?: UploadedFile) => void;
  isLoading: boolean;
  mode: 'chat' | 'image';
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]);
        };
        reader.onerror = error => reject(error);
    });
};

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading, mode }) => {
  const [input, setInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file && file.type.startsWith('image/')) {
          setSelectedFile(file);
          setPreviewUrl(URL.createObjectURL(file));
      }
      if(fileInputRef.current) {
          fileInputRef.current.value = '';
      }
  };

  const removeFile = () => {
      setSelectedFile(null);
      if(previewUrl) {
          URL.revokeObjectURL(previewUrl);
          setPreviewUrl(null);
      }
  };
  
  const handleUploadClick = () => {
      fileInputRef.current?.click();
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((input.trim() || selectedFile) && !isLoading) {
      let uploadedFile: UploadedFile | undefined = undefined;
      if (selectedFile) {
          const base64Data = await fileToBase64(selectedFile);
          uploadedFile = {
              name: selectedFile.name,
              type: selectedFile.type,
              data: base64Data,
          };
      }
      onSendMessage(input.trim(), uploadedFile);
      setInput('');
      removeFile();
    }
  };
  
  const placeholderText = mode === 'chat' 
    ? 'Pergunte ou anexe uma imagem...' 
    : 'Descreva uma imagem... use --negative ou --aspect';

  return (
    <div className="px-2 py-3 sm:p-4 bg-slate-800 border-t border-slate-700">
        {previewUrl && (
            <div className="relative inline-block mb-2 p-2 bg-slate-700 rounded-lg">
                <img src={previewUrl} alt="Preview" className="h-20 w-auto rounded" />
                <button
                    onClick={removeFile}
                    className="absolute -top-2 -right-2 bg-slate-600 hover:bg-red-500 text-white rounded-full p-1 transition-colors"
                    aria-label="Remover imagem"
                >
                    <CloseIcon />
                </button>
            </div>
        )}
        <form onSubmit={handleSubmit} className="flex items-center gap-3">
            {mode === 'chat' && (
                <>
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        className="hidden"
                        accept="image/*"
                        disabled={isLoading}
                    />
                    <button
                        type="button"
                        onClick={handleUploadClick}
                        className="text-slate-400 hover:text-white disabled:opacity-50 transition-colors p-2"
                        disabled={isLoading}
                        aria-label="Anexar arquivo"
                    >
                        <PaperclipIcon />
                    </button>
                </>
            )}
            <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={placeholderText}
                className="flex-grow bg-slate-900 rounded-full py-3 px-5 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300 disabled:opacity-50"
                disabled={isLoading}
            />
            <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-full p-3 transition-colors duration-300 flex items-center justify-center w-12 h-12"
                disabled={isLoading || (!input.trim() && !selectedFile)}
            >
                {isLoading ? <LoadingSpinner /> : <SendIcon />}
            </button>
        </form>
    </div>
  );
};

export default ChatInput;
