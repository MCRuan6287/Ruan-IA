

const CACHE_NAME = 'ruan-ia-cache-v6';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/index.tsx',
  '/App.tsx',
  '/types.ts',
  '/config.ts',
  '/services/geminiService.ts',
  '/services/authService.ts',
  '/components/Header.tsx',
  '/components/ChatInput.tsx',
  '/components/ChatMessage.tsx',
  '/components/icons.tsx',
  '/components/Login.tsx',
  '/components/ModeSwitcher.tsx',
  '/components/ImageModal.tsx',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  'https://cdn.tailwindcss.com',
];

// Evento de instalação: armazena os assets principais em cache.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Service Worker: Caching App Shell');
        return cache.addAll(urlsToCache);
      })
  );
});

// Evento de fetch: serve os assets do cache primeiro (Cache-First).
self.addEventListener('fetch', event => {
  // Ignora requisições que não são GET
  if (event.request.method !== 'GET') {
    return;
  }
  
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Se encontrar no cache, retorna a resposta do cache.
        if (response) {
          return response;
        }
        // Se não, busca na rede.
        return fetch(event.request).catch(() => {
            // Fallback para uma página offline genérica se a busca na rede falhar
            // e o recurso não estiver no cache. Poderia ser um '/offline.html'
        });
      }
    )
  );
});

// Evento de ativação: limpa caches antigos.
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Service Worker: Deleting old cache', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
