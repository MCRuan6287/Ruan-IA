import React, { useEffect } from 'react';
import { Message } from '../types';
import { CloseIcon, DownloadIcon } from './icons';

interface ImageModalProps {
  message: Message | null;
  onClose: () => void;
}

const ImageModal: React.FC<ImageModalProps> = ({ message, onClose }) => {
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);
  
  if (!message || !message.imageUrl) {
    return null;
  }

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = message.imageUrl!;
    link.download = `ruan-ia-${message.text.substring(0, 20).replace(/\s+/g, '_')}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="image-modal-title"
    >
      <div 
        className="bg-slate-800 rounded-xl shadow-2xl max-w-4xl max-h-[90vh] w-full flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 flex justify-between items-center border-b border-slate-700">
          <h2 id="image-modal-title" className="text-lg font-semibold text-slate-200 truncate pr-4">
            Imagem Gerada
          </h2>
          <button 
            onClick={onClose} 
            className="text-slate-400 hover:text-white transition-colors"
            aria-label="Fechar modal"
          >
            <CloseIcon />
          </button>
        </div>
        
        <div className="p-4 flex-1 flex flex-col md:flex-row gap-4 overflow-y-auto">
          <div className="flex-1 flex items-center justify-center bg-black/20 rounded-lg">
            <img 
              src={message.imageUrl} 
              alt={message.text} 
              className="max-w-full max-h-[60vh] md:max-h-full object-contain"
            />
          </div>
        </div>

        <div className="p-4 border-t border-slate-700 bg-slate-900/50 rounded-b-xl">
          <p className="text-sm text-slate-400 mb-1">
            <span className="font-bold text-slate-300">Prompt:</span> {message.text}
          </p>
          {message.negativePrompt && (
            <p className="text-sm text-slate-400 mb-1">
              <span className="font-bold text-slate-300">Prompt Negativo:</span> {message.negativePrompt}
            </p>
          )}
          {message.aspectRatio && (
            <p className="text-sm text-slate-400 mb-3">
              <span className="font-bold text-slate-300">Proporção:</span> {message.aspectRatio}
            </p>
          )}
          <button
            onClick={handleDownload}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition-colors duration-300 flex items-center justify-center gap-2"
          >
            <DownloadIcon />
            Baixar Imagem
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImageModal;
