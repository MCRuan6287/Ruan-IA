import { User } from '../types';

interface StoredUser extends User {
  password?: string;
}

const USERS_KEY = 'ruan_ia_users';
const SESSION_KEY = 'ruan_ia_session';

class AuthService {
  
  private getUsers(): Record<string, StoredUser> {
    const users = localStorage.getItem(USERS_KEY);
    return users ? JSON.parse(users) : {};
  }

  private saveUsers(users: Record<string, StoredUser>): void {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  public signUp(name: string, email: string, password: string): User {
    const users = this.getUsers();
    
    if (users[email.toLowerCase()]) {
      throw new Error("Já existe uma conta com este e-mail.");
    }
    
    if(password.length < 6) {
         throw new Error("A senha deve ter pelo menos 6 caracteres.");
    }

    const newUser: StoredUser = {
      name,
      email: email.toLowerCase(),
      password: password,
      picture: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&color=fff`,
    };

    users[newUser.email] = newUser;
    this.saveUsers(users);
    
    this.createSession(newUser);
    
    return this.getCleanUser(newUser);
  }

  public login(email: string, password: string): User {
    const users = this.getUsers();
    const user = users[email.toLowerCase()];

    if (!user || user.password !== password) {
      throw new Error("E-mail ou senha inválidos.");
    }
    
    this.createSession(user);
    
    return this.getCleanUser(user);
  }
  
  public logout(): void {
    localStorage.removeItem(SESSION_KEY);
  }

  public getCurrentUser(): User | null {
    const session = localStorage.getItem(SESSION_KEY);
    if(!session) return null;

    const users = this.getUsers();
    const user = users[session];

    return user ? this.getCleanUser(user) : null;
  }
  
  private createSession(user: StoredUser): void {
    localStorage.setItem(SESSION_KEY, user.email);
  }

  private getCleanUser(user: StoredUser): User {
    const { name, email, picture } = user;
    return { name, email, picture };
  }
}

const authService = new AuthService();
export default authService;
