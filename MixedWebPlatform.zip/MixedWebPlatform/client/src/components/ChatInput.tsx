import React, { useState, useRef } from 'react';
import { SendIcon, LoadingSpinner, PaperclipIcon } from './icons';
import { UploadedFile } from '../types';

interface ChatInputProps {
  mode: 'chat' | 'image';
  onSendMessage: (text: string, file?: UploadedFile, negativePrompt?: string, aspectRatio?: string) => void;
  disabled: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ mode, onSendMessage, disabled }) => {
  const [message, setMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState<UploadedFile | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() && !selectedFile) return;

    let text = message.trim();
    let negativePrompt = '';
    let aspectRatio = '';

    if (mode === 'image') {
      // Parse special commands for image generation
      const negativeMatch = text.match(/--negative\s+(.+?)(?:\s+--|$)/);
      if (negativeMatch) {
        negativePrompt = negativeMatch[1].trim();
        text = text.replace(/--negative\s+.+?(?:\s+--|$)/, '').trim();
      }

      const aspectMatch = text.match(/--aspect\s+(1:1|16:9|9:16|4:3|3:4)(?:\s+--|$)/);
      if (aspectMatch) {
        aspectRatio = aspectMatch[1];
        text = text.replace(/--aspect\s+\S+(?:\s+--|$)/, '').trim();
      }
    }

    onSendMessage(text, selectedFile || undefined, negativePrompt, aspectRatio);
    setMessage('');
    setSelectedFile(null);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        const base64Data = base64.split(',')[1]; // Remove data:image/type;base64, prefix
        
        setSelectedFile({
          name: file.name,
          type: file.type,
          data: base64Data
        });
      };
      reader.readAsDataURL(file);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  const placeholder = mode === 'chat' 
    ? 'Pergunte ou anexe uma imagem...' 
    : 'Descreva uma imagem... use --negative ou --aspect';

  return (
    <div className="px-2 py-3 sm:p-4 bg-slate-800 border-t border-slate-700">
      {selectedFile && (
        <div className="relative inline-block mb-2 p-2 bg-slate-700 rounded-lg">
          <img 
            src={`data:${selectedFile.type};base64,${selectedFile.data}`} 
            alt="Preview" 
            className="h-20 w-auto rounded" 
          />
          <button 
            onClick={removeFile}
            className="absolute -top-2 -right-2 bg-slate-600 hover:bg-red-500 text-white rounded-full p-1 transition-colors" 
            aria-label="Remover imagem"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="flex items-center gap-3">
        <input 
          type="file" 
          ref={fileInputRef}
          className="hidden" 
          accept="image/*" 
          onChange={handleFileSelect}
        />
        
        {mode === 'chat' && (
          <button
            type="button"
            onClick={triggerFileUpload}
            disabled={disabled}
            className="text-slate-400 hover:text-white disabled:opacity-50 transition-colors p-2"
            aria-label="Anexar arquivo"
          >
            <PaperclipIcon />
          </button>
        )}
        
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className="flex-grow bg-slate-900 rounded-full py-3 px-5 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300 disabled:opacity-50"
        />
        
        <button
          type="submit"
          disabled={disabled || (!message.trim() && !selectedFile)}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-full p-3 transition-colors duration-300 flex items-center justify-center w-12 h-12"
        >
          {disabled ? <LoadingSpinner /> : <SendIcon />}
        </button>
      </form>
    </div>
  );
};

export default ChatInput;
