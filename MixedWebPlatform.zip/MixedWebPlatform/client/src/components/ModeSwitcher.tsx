import React from 'react';
import { ChatBubbleIcon, ImageIcon } from './icons';

type Mode = 'chat' | 'image';

interface ModeSwitcherProps {
  mode: Mode;
  setMode: (mode: Mode) => void;
}

const ModeSwitcher: React.FC<ModeSwitcherProps> = ({ mode, setMode }) => {
  return (
    <div className="flex justify-center p-2 bg-slate-800">
      <div className="inline-flex rounded-md shadow-sm bg-slate-900 p-1" role="group">
        <button
          type="button"
          onClick={() => setMode('chat')}
          className={`inline-flex items-center px-4 py-2 text-sm font-medium rounded-l-lg transition-colors focus:z-10 focus:outline-none focus:ring-2 focus:ring-blue-500 ${mode === 'chat' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`}
        >
          <ChatBubbleIcon />
          Chat
        </button>
        <button
          type="button"
          onClick={() => setMode('image')}
          className={`inline-flex items-center px-4 py-2 text-sm font-medium rounded-r-lg transition-colors focus:z-10 focus:outline-none focus:ring-2 focus:ring-blue-500 ${mode === 'image' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`}
        >
          <ImageIcon />
          Imagem
        </button>
      </div>
    </div>
  );
};

export default ModeSwitcher;
