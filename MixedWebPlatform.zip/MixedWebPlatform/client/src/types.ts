export interface User {
  id?: number;
  name: string;
  email: string;
  picture?: string;
}

export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
  IMAGE = 'image',
  ERROR = 'error'
}

export interface Message {
  id: string;
  role: MessageRole;
  text: string;
  imageUrl?: string;
  file?: UploadedFile;
  negativePrompt?: string;
  aspectRatio?: string;
  groundingMetadata?: any;
  timestamp: Date;
}

export interface UploadedFile {
  name: string;
  type: string;
  data: string; // base64 encoded
}
