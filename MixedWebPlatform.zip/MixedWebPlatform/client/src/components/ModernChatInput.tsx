import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Send, Upload, MessageSquare, ImageIcon, Info } from 'lucide-react';
import { FileUpload } from './FileUpload';
import { UploadedFile } from '../types';

interface ModernChatInputProps {
  mode: 'chat' | 'image';
  onSendMessage: (text: string, file?: UploadedFile, negativePrompt?: string, aspectRatio?: string) => void;
  disabled: boolean;
}

const ModernChatInput: React.FC<ModernChatInputProps> = ({ mode, onSendMessage, disabled }) => {
  const [message, setMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFileData, setSelectedFileData] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() && !selectedFile) return;

    let text = message.trim();
    let negativePrompt = '';
    let aspectRatio = '';

    if (mode === 'image') {
      // Parse special commands for image generation
      const negativeMatch = text.match(/--negative\s+(.+?)(?:\s+--|$)/);
      if (negativeMatch) {
        negativePrompt = negativeMatch[1].trim();
        text = text.replace(/--negative\s+.+?(?:\s+--|$)/, '').trim();
      }

      const aspectMatch = text.match(/--aspect\s+(1:1|16:9|9:16|4:3|3:4)(?:\s+--|$)/);
      if (aspectMatch) {
        aspectRatio = aspectMatch[1];
        text = text.replace(/--aspect\s+\S+(?:\s+--|$)/, '').trim();
      }
    }

    let uploadedFile: UploadedFile | undefined;
    if (selectedFile && selectedFileData) {
      const base64Data = selectedFileData.split(',')[1]; // Remove data:type;base64, prefix
      uploadedFile = {
        name: selectedFile.name,
        type: selectedFile.type,
        data: base64Data
      };
    }

    onSendMessage(text, uploadedFile, negativePrompt, aspectRatio);
    setMessage('');
    setSelectedFile(null);
    setSelectedFileData('');
  };

  const handleFileSelect = (file: File, base64: string) => {
    setSelectedFile(file);
    setSelectedFileData(base64);
  };

  const getModeInfo = () => {
    if (mode === 'chat') {
      return {
        icon: <MessageSquare className="h-4 w-4" />,
        title: "Modo Chat",
        description: "Converse com a IA e faça upload de imagens para análise",
        placeholder: "Digite sua mensagem aqui...",
        color: "bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800"
      };
    } else {
      return {
        icon: <ImageIcon className="h-4 w-4" />,
        title: "Modo Imagem",
        description: "Gere imagens incríveis com IA",
        placeholder: "Descreva a imagem que você quer criar...",
        color: "bg-purple-50 dark:bg-purple-950 border-purple-200 dark:border-purple-800"
      };
    }
  };

  const modeInfo = getModeInfo();

  return (
    <div className="p-4 space-y-4">
      {/* Mode Info */}
      <Card className={`${modeInfo.color}`}>
        <CardContent className="flex items-center gap-3 py-3">
          {modeInfo.icon}
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{modeInfo.title}</Badge>
              {mode === 'image' && (
                <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                  <Info className="h-3 w-3" />
                  <span>Use --negative ou --aspect para mais controle</span>
                </div>
              )}
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {modeInfo.description}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* File Upload */}
      <FileUpload 
        mode={mode} 
        onFileSelect={handleFileSelect}
        maxSize={10}
      />

      {/* Message Input */}
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="relative">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={modeInfo.placeholder}
            className="min-h-20 pr-12 resize-none"
            disabled={disabled}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <Button
            type="submit"
            size="sm"
            className="absolute bottom-2 right-2"
            disabled={disabled || (!message.trim() && !selectedFile)}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {/* Command Hints for Image Mode */}
        {mode === 'image' && (
          <div className="flex flex-wrap gap-2 text-xs text-gray-500 dark:text-gray-400">
            <span>Dicas:</span>
            <Badge variant="outline" className="text-xs">
              --negative [texto] (o que evitar)
            </Badge>
            <Badge variant="outline" className="text-xs">
              --aspect 16:9 (proporção)
            </Badge>
          </div>
        )}
      </form>
    </div>
  );
};

export default ModernChatInput;