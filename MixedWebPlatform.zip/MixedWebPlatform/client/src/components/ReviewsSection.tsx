import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Star, StarIcon } from "lucide-react";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Review {
  id: number;
  userId: number;
  rating: number;
  comment: string;
  createdAt: string;
}

interface ReviewsSectionProps {
  currentUserId?: number;
}

export function ReviewsSection({ currentUserId }: ReviewsSectionProps) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reviewsData } = useQuery<{ reviews: Review[] }>({
    queryKey: ["/api/reviews"]
  });

  const createReviewMutation = useMutation({
    mutationFn: async (reviewData: { userId: number; rating: number; comment: string }) => {
      return apiRequest("/api/reviews", "POST", reviewData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      setComment("");
      setRating(5);
      toast({
        title: "Avaliação enviada!",
        description: "Obrigado pelo seu feedback.",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível enviar a avaliação.",
        variant: "destructive",
      });
    }
  });

  const handleSubmitReview = () => {
    if (!currentUserId) {
      toast({
        title: "Faça login",
        description: "Você precisa estar logado para avaliar.",
        variant: "destructive",
      });
      return;
    }

    if (comment.trim().length < 10) {
      toast({
        title: "Comentário muito curto",
        description: "Por favor, escreva pelo menos 10 caracteres.",
        variant: "destructive",
      });
      return;
    }

    createReviewMutation.mutate({
      userId: currentUserId,
      rating,
      comment: comment.trim()
    });
  };

  const reviews = reviewsData?.reviews || [];
  const averageRating = reviews.length > 0 
    ? reviews.reduce((sum: number, review: Review) => sum + review.rating, 0) / reviews.length 
    : 0;

  return (
    <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950 border-yellow-200 dark:border-yellow-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
          <Star className="h-5 w-5 fill-current" />
          Avaliações dos Usuários
        </CardTitle>
        {reviews.length > 0 && (
          <div className="flex items-center gap-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <StarIcon
                  key={star}
                  className={`h-4 w-4 ${
                    star <= averageRating
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {averageRating.toFixed(1)} de 5 ({reviews.length} avaliações)
            </span>
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Add Review Form */}
        {currentUserId && (
          <div className="space-y-4 p-4 bg-white dark:bg-gray-800 rounded-lg border">
            <h3 className="font-medium text-gray-900 dark:text-gray-100">
              Deixe sua avaliação
            </h3>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Classificação:
              </label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    <StarIcon
                      className={`h-6 w-6 ${
                        star <= rating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300 hover:text-yellow-300"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Comentário:
              </label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Conte-nos sobre sua experiência com o Ruan IA..."
                className="min-h-20"
              />
            </div>
            <Button 
              onClick={handleSubmitReview}
              disabled={createReviewMutation.isPending || comment.trim().length < 10}
              className="w-full"
            >
              {createReviewMutation.isPending ? "Enviando..." : "Enviar Avaliação"}
            </Button>
          </div>
        )}

        {/* Reviews List */}
        <div className="space-y-4">
          {reviews.map((review: Review) => (
            <div key={review.id} className="p-4 bg-white dark:bg-gray-800 rounded-lg border">
              <div className="flex items-center justify-between mb-2">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <StarIcon
                      key={star}
                      className={`h-4 w-4 ${
                        star <= review.rating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <Badge variant="outline">
                  {new Date(review.createdAt).toLocaleDateString('pt-BR')}
                </Badge>
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                {review.comment}
              </p>
            </div>
          ))}
        </div>

        {reviews.length === 0 && (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <Star className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Seja o primeiro a avaliar o Ruan IA!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}