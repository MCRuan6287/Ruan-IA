
import React from 'react';
import { Message, MessageRole } from '../types';
import { UserIcon, BotIcon, LoadingSpinner, DownloadIcon, SourceIcon } from './icons';

interface ChatMessageProps {
  message: Message;
  onImageClick: (message: Message) => void;
}

const TypingIndicator: React.FC = () => (
    <div className="flex items-start gap-4 p-4 md:p-6">
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-slate-600 flex items-center justify-center">
            <BotIcon />
        </div>
        <div className="bg-slate-700 rounded-xl px-4 py-3 shadow-lg flex items-center space-x-2">
           <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '0s' }}></div>
           <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
           <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
        </div>
    </div>
);

const GroundingSources: React.FC<{ metadata: any }> = ({ metadata }) => {
    if (!metadata?.groundingChunks?.length) return null;
    
    const sources = metadata.groundingChunks
        .map((chunk: any) => chunk.web)
        .filter((source: any, index: number, self: any[]) => 
            source && self.findIndex(s => s.uri === source.uri) === index
        );

    if (sources.length === 0) return null;

    return (
        <div className="mt-3 pt-3 border-t border-slate-600">
            <h4 className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-2">
                <SourceIcon />
                Fontes
            </h4>
            <ul className="space-y-1">
                {sources.map((source: any, index: number) => (
                    <li key={index}>
                        <a 
                            href={source.uri} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-400 hover:text-blue-300 text-sm hover:underline line-clamp-1"
                            title={source.title || source.uri}
                        >
                            {source.title || source.uri}
                        </a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const ImageGeneratingIndicator: React.FC<{ message: Message }> = ({ message }) => (
    <div className="flex items-start gap-4 p-4 md:p-6">
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-slate-600 flex items-center justify-center">
            <BotIcon />
        </div>
        <div className="bg-slate-700 rounded-xl px-4 py-3 shadow-lg max-w-[85%] sm:max-w-lg md:max-w-2xl lg:max-w-3xl">
            <p className="text-sm italic text-slate-400 mb-2">Gerando imagem para: "{message.text}"</p>
            {message.negativePrompt && <p className="text-xs text-slate-400">Negativo: {message.negativePrompt}</p>}
            {message.aspectRatio && <p className="text-xs text-slate-400">Proporção: {message.aspectRatio}</p>}
            <div className="flex items-center space-x-2 text-slate-300 mt-2">
               <LoadingSpinner />
                <span>Aguarde...</span>
            </div>
        </div>
    </div>
);

const downloadImage = (url: string, filename: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || 'ruan-ia-image.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

const ChatMessage: React.FC<ChatMessageProps> = ({ message, onImageClick }) => {
  if (message.role === MessageRole.MODEL && message.text === '') {
    return <TypingIndicator />;
  }
  if (message.role === MessageRole.IMAGE && !message.imageUrl) {
    return <ImageGeneratingIndicator message={message} />;
  }

  const isUser = message.role === MessageRole.USER;
  const isError = message.role === MessageRole.ERROR;
  const isImage = message.role === MessageRole.IMAGE;

  const wrapperClasses = `flex items-start gap-4`;
  const bubbleClasses = `relative rounded-xl shadow-lg max-w-[85%] sm:max-w-lg md:max-w-2xl lg:max-w-3xl`;

  const userBubbleClasses = 'bg-blue-600 text-white rounded-br-none px-4 py-3';
  const modelBubbleClasses = 'bg-slate-700 text-slate-200 rounded-bl-none';
  const errorBubbleClasses = 'bg-red-500/20 text-red-300 border border-red-500/50 rounded-bl-none px-4 py-3';
  
  const textBubbleContainerClasses = 'px-4 py-3';
  const imageBubbleContainerClasses = 'p-2';

  const bubbleContent = 
    isImage && message.imageUrl ? (
      <div className="flex flex-col group">
        <button onClick={() => onImageClick(message)} className="relative focus:outline-none rounded-lg" aria-label="Ampliar imagem">
            <img src={message.imageUrl} alt={message.text} className="rounded-lg max-w-full h-auto shadow-md" />
        </button>
        <button
            onClick={() => downloadImage(message.imageUrl!, `ruan-ia-${message.text.substring(0, 20)}.jpg`)}
            className="absolute top-2 right-2 bg-slate-900/50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            aria-label="Baixar imagem"
        >
            <DownloadIcon />
        </button>
        <div className="text-sm italic text-slate-400 pt-2 px-1">
          <p>{message.text}</p>
          {message.negativePrompt && <p className="text-xs mt-1">Negativo: {message.negativePrompt}</p>}
          {message.aspectRatio && <p className="text-xs">Proporção: {message.aspectRatio}</p>}
        </div>
      </div>
    ) : (
      <div className="flex flex-col">
        {isUser && message.file && message.file.type.startsWith('image/') && (
            <div className="mb-2">
                <img 
                    src={`data:${message.file.type};base64,${message.file.data}`} 
                    alt={message.file.name} 
                    className="max-w-xs max-h-48 rounded-lg" 
                />
            </div>
        )}
        {message.text && <p className="whitespace-pre-wrap">{message.text}</p>}
        {!isUser && message.groundingMetadata && <GroundingSources metadata={message.groundingMetadata} />}
      </div>
    );

  return (
    <div className={`${wrapperClasses} ${isUser ? 'justify-end' : ''}`}>
      {!isUser && (
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-slate-600 flex items-center justify-center">
            <BotIcon />
        </div>
      )}
      <div className={`${bubbleClasses} ${isUser ? userBubbleClasses : isError ? errorBubbleClasses : isImage ? `${modelBubbleClasses} ${imageBubbleContainerClasses}` : `${modelBubbleClasses} ${textBubbleContainerClasses}`}`}>
        {bubbleContent}
      </div>
      {isUser && (
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-slate-600 flex items-center justify-center">
            <UserIcon />
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
