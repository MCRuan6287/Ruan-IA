
import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import ModeSwitcher from './components/ModeSwitcher';
import Login from './components/Login';
import ImageModal from './components/ImageModal';
import { Message, MessageRole, User, UploadedFile } from './types';
import geminiService from './services/geminiService';
import authService from './services/authService';

type Mode = 'chat' | 'image';

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [apiKeyOk, setApiKeyOk] = useState<boolean>(false);
    const [user, setUser] = useState<User | null>(null);
    const [mode, setMode] = useState<Mode>('chat');
    const [selectedImage, setSelectedImage] = useState<Message | null>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (process.env.API_KEY) {
            setApiKeyOk(true);
        } else {
            setApiKeyOk(false);
        }

        const currentUser = authService.getCurrentUser();
        if (currentUser) {
            setUser(currentUser);
        }
    }, []);
    
    useEffect(() => {
        if (user && messages.length === 0) {
            setMessages([
                {
                    role: MessageRole.MODEL,
                    text: `Olá, ${user.name.split(' ')[0]}! Eu sou o Ruan IA. Alterne entre os modos abaixo para conversar ou criar imagens. Como posso te ajudar hoje?`,
                },
            ]);
        }
    }, [user, messages.length]);

    useEffect(() => {
        chatContainerRef.current?.scrollTo({
            top: chatContainerRef.current.scrollHeight,
            behavior: 'smooth',
        });
    }, [messages]);
    
    const handleAuthSuccess = (loggedInUser: User) => {
        setUser(loggedInUser);
    };

    const handleLogout = () => {
        authService.logout();
        setUser(null);
        setMessages([]);
    };

    const handleSendMessage = async (userInput: string, file?: UploadedFile) => {
        if (!userInput.trim() && !file) return;

        setIsLoading(true);
        const userMessage: Message = { role: MessageRole.USER, text: userInput, file };
        
        if (mode === 'chat') {
            setMessages(prev => [...prev, userMessage, { role: MessageRole.MODEL, text: '' }]);
            try {
                let fullResponse = '';
                const stream = geminiService.sendMessageStream(userInput, file);

                for await (const chunk of stream) {
                    if (chunk.type === 'text') {
                        fullResponse += chunk.payload;
                        setMessages(prev => {
                            const newMessages = [...prev];
                            const lastMessage = newMessages[newMessages.length - 1];
                            if(lastMessage.role === MessageRole.MODEL) {
                                lastMessage.text = fullResponse;
                            }
                            return newMessages;
                        });
                    } else if (chunk.type === 'metadata') {
                         setMessages(prev => {
                            const newMessages = [...prev];
                            const lastMessage = newMessages[newMessages.length - 1];
                            if(lastMessage.role === MessageRole.MODEL) {
                                lastMessage.groundingMetadata = chunk.payload;
                            }
                            return newMessages;
                        });
                    }
                }
            } catch (error) {
                const errorMessage = error instanceof Error ? error.message : "Ocorreu um erro desconhecido.";
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { role: MessageRole.ERROR, text: `Erro: ${errorMessage}` };
                    return newMessages;
                });
            } finally {
                setIsLoading(false);
            }
        } else { // mode === 'image'
            const negativePromptRegex = /--negative\s+([^--]+)/;
            const aspectRatioRegex = /--aspect\s+(1:1|9:16|16:9|4:3|3:4)/;

            const negativePromptMatch = userInput.match(negativePromptRegex);
            const aspectRatioMatch = userInput.match(aspectRatioRegex);
            
            const negativePrompt = negativePromptMatch ? negativePromptMatch[1].trim() : undefined;
            const aspectRatio = aspectRatioMatch ? aspectRatioMatch[1].trim() as "1:1" | "9:16" | "16:9" | "4:3" | "3:4" : undefined;
            
            const prompt = userInput.replace(negativePromptRegex, '').replace(aspectRatioRegex, '').trim();

            const imageRequestMessage: Message = { 
                role: MessageRole.IMAGE, 
                text: prompt, 
                imageUrl: '', 
                negativePrompt, 
                aspectRatio 
            };

            setMessages(prev => [...prev, userMessage, imageRequestMessage]);
            try {
                const imageUrl = await geminiService.generateImage({ prompt, negativePrompt, aspectRatio });
                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMessage = newMessages[newMessages.length - 1];
                    if (lastMessage.role === MessageRole.IMAGE) {
                        lastMessage.imageUrl = imageUrl;
                    }
                    return newMessages;
                });
            } catch (error) {
                const errorMessage = error instanceof Error ? error.message : "Ocorreu um erro desconhecido.";
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { role: MessageRole.ERROR, text: `Erro ao gerar imagem: ${errorMessage}` };
                    return newMessages;
                });
            } finally {
                setIsLoading(false);
            }
        }
    };

    const handleImageClick = (message: Message) => {
        if (message.role === MessageRole.IMAGE && message.imageUrl) {
            setSelectedImage(message);
        }
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
    };
    
    if (!apiKeyOk) {
        return (
            <div className="flex flex-col items-center justify-center h-screen bg-slate-900 text-slate-300 p-4">
                <h1 className="text-3xl font-bold text-red-500 mb-4">Erro de Configuração</h1>
                <p className="text-center max-w-md">
                    A chave da API Gemini não está configurada. Por favor, defina a variável de ambiente `API_KEY` para usar esta aplicação.
                </p>
                 <div className="mt-6 p-4 bg-slate-800 rounded-lg text-sm font-mono">
                    <code>process.env.API_KEY está ausente.</code>
                </div>
            </div>
        );
    }
    
    if (!user) {
        return <Login onAuthSuccess={handleAuthSuccess} />;
    }

    return (
        <div className="flex flex-col h-screen bg-slate-900 text-slate-200 font-sans">
            <Header user={user} onLogout={handleLogout} />
            <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-4">
                {messages.map((msg, index) => (
                    <ChatMessage key={index} message={msg} onImageClick={handleImageClick} />
                ))}
            </main>
            <div className="w-full">
              <ModeSwitcher mode={mode} setMode={setMode} />
              <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} mode={mode} />
            </div>
            {selectedImage && <ImageModal message={selectedImage} onClose={handleCloseModal} />}
        </div>
    );
};

export default App;
