
import { GoogleGenAI, Chat, GenerateContentResponse, Part } from "@google/genai";
import { UploadedFile } from '../types';

if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set. Service will not be initialized.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

interface ImageGenerationParams {
    prompt: string;
    negativePrompt?: string;
    aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4";
}

class GeminiChatService {
    private chat: Chat | null = null;

    private initializeChat(): Chat {
        if (!this.chat) {
            this.chat = ai.chats.create({
                model: 'gemini-2.5-flash',
                config: {
                  systemInstruction: 'You are a helpful and creative AI assistant named Ruan IA. Provide clear, concise, and friendly responses. When asked for information that might be recent or require web access, you will use your search tool to provide up-to-date answers and cite your sources.',
                  tools: [{ googleSearch: {} }],
                },
            });
        }
        return this.chat;
    }

    public async *sendMessageStream(message: string, file?: UploadedFile): AsyncGenerator<{type: 'text'; payload: string} | {type: 'metadata'; payload: any}> {
        if (!process.env.API_KEY) {
            throw new Error("API_KEY environment variable not set");
        }
        
        try {
            const chat = this.initializeChat();
            
            let streamRequest: string | Part[];
            if (file) {
                streamRequest = [
                    { text: message },
                    {
                        inlineData: {
                            mimeType: file.type,
                            data: file.data
                        }
                    }
                ];
            } else {
                streamRequest = message;
            }

            const result = await chat.sendMessageStream({ message: streamRequest });
            let finalResponse: GenerateContentResponse | null = null;

            for await (const chunk of result) {
                finalResponse = chunk;
                if (chunk.text) {
                    yield { type: 'text', payload: chunk.text };
                }
            }
            
            const metadata = finalResponse?.candidates?.[0]?.groundingMetadata;
            if (metadata?.groundingChunks?.length) {
                yield { type: 'metadata', payload: metadata };
            }

        } catch (error) {
            console.error("Error sending message to Gemini:", error);
            throw new Error("Falha ao obter resposta da IA. Verifique sua chave de API e conexão de rede.");
        }
    }
    
    public async generateImage(params: ImageGenerationParams): Promise<string> {
        if (!process.env.API_KEY) {
            throw new Error("API_KEY environment variable not set");
        }
        try {
            const response = await ai.models.generateImages({
                model: 'imagen-3.0-generate-002',
                prompt: params.prompt,
                config: {
                  numberOfImages: 1,
                  outputMimeType: 'image/jpeg',
                  aspectRatio: params.aspectRatio || '1:1',
                  negativePrompt: params.negativePrompt,
                },
            });

            if (response.generatedImages && response.generatedImages.length > 0) {
                const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
                return `data:image/jpeg;base64,${base64ImageBytes}`;
            } else {
                 throw new Error("A IA não conseguiu gerar uma imagem. Tente um prompt diferente.");
            }
        } catch (error) {
            console.error("Error generating image with Imagen:", error);
            throw new Error("Falha ao gerar a imagem. Verifique seu prompt e tente novamente.");
        }
    }
}

const geminiService = new GeminiChatService();
export default geminiService;