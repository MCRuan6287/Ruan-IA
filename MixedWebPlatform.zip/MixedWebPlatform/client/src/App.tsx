import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ModernLogin from './components/ModernLogin';
import ChatMessage from './components/ChatMessage';
import ModernChatInput from './components/ModernChatInput';
import ModeSwitcher from './components/ModeSwitcher';
import ImageModal from './components/ImageModal';
import { SystemInfo } from './components/SystemInfo';
import { ReviewsSection } from './components/ReviewsSection';
import { User, Message, MessageRole, UploadedFile } from './types';
import authService from './services/authService';
import geminiService from './services/geminiService';

type Mode = 'chat' | 'image';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [mode, setMode] = useState<Mode>('chat');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<Message | null>(null);
  const [showInfo, setShowInfo] = useState(false);

  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      // Add welcome message
      setMessages([{
        id: '0',
        role: MessageRole.MODEL,
        text: `Olá, ${currentUser.name.split(' ')[0]}! Eu sou o Ruan IA. Alterne entre os modos abaixo para conversar ou criar imagens. Como posso te ajudar hoje?`,
        timestamp: new Date(),
      }]);
    }
  }, []);

  const handleAuthSuccess = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    setMessages([{
      id: '0',
      role: MessageRole.MODEL,
      text: `Olá, ${authenticatedUser.name.split(' ')[0]}! Eu sou o Ruan IA. Alterne entre os modos abaixo para conversar ou criar imagens. Como posso te ajudar hoje?`,
      timestamp: new Date(),
    }]);
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
    setMessages([]);
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      const chatContainer = document.getElementById('chat-container');
      if (chatContainer) {
        chatContainer.scrollTo({
          top: chatContainer.scrollHeight,
          behavior: 'smooth'
        });
      }
    }, 100);
  };

  const handleSendMessage = async (text: string, file?: UploadedFile, negativePrompt?: string, aspectRatio?: string) => {
    if (!text.trim() && !file) return;

    setIsLoading(true);

    try {
      if (mode === 'chat') {
        // Add user message
        const userMessage: Message = {
          id: Date.now().toString(),
          role: MessageRole.USER,
          text,
          file,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, userMessage]);

        // Add typing indicator
        const typingMessage: Message = {
          id: 'typing',
          role: MessageRole.MODEL,
          text: '',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, typingMessage]);
        scrollToBottom();

        // Get AI response
        let aiResponse = '';
        let groundingMetadata: any = null;

        const responseStream = geminiService.sendMessageStream(text, file);
        
        for await (const chunk of responseStream) {
          if (chunk.type === 'text') {
            aiResponse += chunk.payload;
            // Update the typing message with partial response
            setMessages(prev => prev.map(msg => 
              msg.id === 'typing' ? { ...msg, text: aiResponse } : msg
            ));
            scrollToBottom();
          } else if (chunk.type === 'metadata') {
            groundingMetadata = chunk.payload;
          }
        }

        // Replace typing message with final response
        setMessages(prev => prev.map(msg => 
          msg.id === 'typing' 
            ? { ...msg, id: Date.now().toString(), groundingMetadata } 
            : msg
        ));

      } else if (mode === 'image') {
        // Add image generation request
        const imageMessage: Message = {
          id: Date.now().toString(),
          role: MessageRole.IMAGE,
          text,
          negativePrompt,
          aspectRatio,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, imageMessage]);
        scrollToBottom();

        // Generate image
        const imageUrl = await geminiService.generateImage({
          prompt: text,
          negativePrompt,
          aspectRatio: aspectRatio as any
        });

        // Update message with generated image
        setMessages(prev => prev.map(msg => 
          msg.id === imageMessage.id ? { ...msg, imageUrl } : msg
        ));
      }
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: MessageRole.ERROR,
        text: error instanceof Error ? error.message : 'Ocorreu um erro inesperado.',
        timestamp: new Date(),
      };
      setMessages(prev => prev.filter(msg => msg.id !== 'typing').concat(errorMessage));
    } finally {
      setIsLoading(false);
      scrollToBottom();
    }
  };

  const handleImageClick = (message: Message) => {
    setSelectedImage(message);
  };

  const closeImageModal = () => {
    setSelectedImage(null);
  };

  if (!user) {
    return <ModernLogin onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 text-gray-900 dark:text-gray-100">
      <Header user={user} onLogout={handleLogout} />
      
      {showInfo ? (
        <main className="flex-1 overflow-y-auto p-4 space-y-6">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Informações do Sistema</h2>
              <button
                onClick={() => setShowInfo(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Voltar ao Chat
              </button>
            </div>
            <SystemInfo />
            <ReviewsSection currentUserId={user.id} />
          </div>
        </main>
      ) : (
        <>
          <main id="chat-container" className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-4">
            {messages.length === 0 && (
              <div className="max-w-2xl mx-auto mt-8 space-y-4">
                <SystemInfo />
                <div className="text-center">
                  <button
                    onClick={() => setShowInfo(true)}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Ver Avaliações dos Usuários
                  </button>
                </div>
              </div>
            )}
            {messages.map((message) => (
              <ChatMessage 
                key={message.id} 
                message={message} 
                onImageClick={handleImageClick}
              />
            ))}
          </main>

          <div className="w-full border-t dark:border-gray-700 bg-white dark:bg-gray-800">
            <div className="max-w-4xl mx-auto">
              <ModeSwitcher mode={mode} setMode={setMode} />
              <ModernChatInput 
                mode={mode}
                onSendMessage={handleSendMessage}
                disabled={isLoading}
              />
            </div>
          </div>
        </>
      )}

      <ImageModal 
        message={selectedImage}
        onClose={closeImageModal}
      />
    </div>
  );
};

export default App;
