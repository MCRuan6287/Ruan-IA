import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMessageSchema, insertReviewSchema } from "@shared/schema";
import bcrypt from "bcrypt";

export async function registerRoutes(app: Express): Promise<Server> {
  // Config route
  app.get("/api/config", (req, res) => {
    res.json({
      geminiApiKey: process.env.GEMINI_API_KEY || ''
    });
  });

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { name, email, password } = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Já existe uma conta com este e-mail." });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user with avatar
      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        picture: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&color=fff`
      });

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(400).json({ message: "Dados inválidos." });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "E-mail ou senha inválidos." });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "E-mail ou senha inválidos." });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(400).json({ message: "Erro no login." });
    }
  });

  // Message routes
  app.get("/api/messages", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID é obrigatório." });
      }

      const messages = await storage.getMessagesByUserId(userId);
      res.json({ messages });
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar mensagens." });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const { userId, role, content, imageUrl, metadata } = req.body;
      
      const message = await storage.createMessage({
        userId,
        role,
        content,
        imageUrl,
        metadata: metadata ? JSON.stringify(metadata) : null
      });

      res.json({ message });
    } catch (error) {
      res.status(500).json({ message: "Erro ao salvar mensagem." });
    }
  });

  // System info route
  app.get("/api/system-info", (req, res) => {
    res.json({
      version: "2.1.0",
      model: "Gemini 2.5 Flash",
      imageModel: "Gemini 2.0 Flash Image Generation",
      features: ["Chat com IA", "Geração de Imagens", "Upload de Arquivos", "PWA"]
    });
  });

  // Reviews routes
  app.get("/api/reviews", async (req, res) => {
    try {
      const reviews = await storage.getReviews();
      res.json({ reviews });
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar avaliações." });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      const reviewData = insertReviewSchema.parse(req.body);
      const review = await storage.createReview(reviewData);
      res.json({ review });
    } catch (error) {
      res.status(400).json({ message: "Dados da avaliação inválidos." });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
