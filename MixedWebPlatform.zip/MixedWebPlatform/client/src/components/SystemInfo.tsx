import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Sparkles, Upload, Smartphone } from "lucide-react";

interface SystemInfo {
  version: string;
  model: string;
  imageModel: string;
  features: string[];
}

export function SystemInfo() {
  const { data: systemInfo } = useQuery<{ version: string; model: string; imageModel: string; features: string[] }>({
    queryKey: ["/api/system-info"]
  });

  if (!systemInfo) return null;

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 border-blue-200 dark:border-blue-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
          <Brain className="h-5 w-5" />
          Ruan IA v{systemInfo.version}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Modelo Principal:
            </p>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
              {systemInfo.model}
            </Badge>
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Modelo de Imagens:
            </p>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
              {systemInfo.imageModel}
            </Badge>
          </div>
        </div>
        
        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Recursos Disponíveis:
          </p>
          <div className="flex flex-wrap gap-2">
            {systemInfo.features.map((feature: string, index: number) => {
              const icons = [
                <Brain className="h-3 w-3" key="brain" />,
                <Sparkles className="h-3 w-3" key="sparkles" />,
                <Upload className="h-3 w-3" key="upload" />,
                <Smartphone className="h-3 w-3" key="smartphone" />
              ];
              return (
                <Badge key={feature} variant="outline" className="flex items-center gap-1">
                  {icons[index]}
                  {feature}
                </Badge>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}